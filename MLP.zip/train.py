import argparse
import yaml
import torch
import logging
import os
import sys
from datetime import datetime
import numpy as np
import sys
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SRC_PATH = os.path.join(BASE_DIR, "src")
sys.path.append(SRC_PATH)

from data.data_loader import DataLoader
from models.networks import DomainAdaptationNetwork
from training.trainer import DomainAdaptationTrainer
from utils.metrics import DomainAdaptationEvaluator


def setup_logging(log_dir):
    os.makedirs(log_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = os.path.join(log_dir, f"training_{timestamp}.log")
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[logging.FileHandler(log_file, encoding="utf-8"), logging.StreamHandler()]
    )
    return logging.getLogger(__name__)

def load_config(path):
    with open(path, 'r') as f:
        return yaml.safe_load(f)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', default='configs/default.yaml')
    parser.add_argument('--gpu', type=int, default=0)
    args = parser.parse_args()

    config = load_config(args.config)
    logger = setup_logging(config['logging']['log_dir'])
    logger.info("Start training (GDSC + TCGA)")

    device = torch.device(f"cuda:{args.gpu}" if (args.gpu >= 0 and torch.cuda.is_available()) else "cpu")
    logger.info(f"Using device: {device}")

    data_loader = DataLoader(config)
    data_loaders = data_loader.create_data_loaders()

    model = DomainAdaptationNetwork(config['model'])
    logger.info(f"Model params: {sum(p.numel() for p in model.parameters()):,}")

    trainer = DomainAdaptationTrainer(
        config=config,
        model=model,
        source_loader=data_loaders['train'],
        val_loader=data_loaders['val'],
        target_loader=data_loaders.get('tcga', None),
        device=device
    )

    best_ckpt = trainer.train()
    if best_ckpt:
        logger.info(f"Loading best model from {best_ckpt}")
        ck = torch.load(best_ckpt, map_location=device)
        model.load_state_dict(ck['model_state_dict'])

    evaluator = DomainAdaptationEvaluator(model, config, device)
    results = evaluator.evaluate_comprehensive(data_loaders)
    logger.info("Evaluation results:")
    for k, v in results.items():
        logger.info(f"{k}: {v}")

if __name__ == '__main__':
    main()
