import torch
import torch.nn as nn
from .gradient_reversal import GradientReversalLayer


class FeatureExtractor(nn.Module):
    def __init__(self, input_dim, hidden_dims, dropout=0.2):
        super(FeatureExtractor, self).__init__()
        layers = []
        prev = input_dim
        for h in hidden_dims:
            layers.extend([
                nn.Linear(prev, h),
                nn.BatchNorm1d(h),
                nn.ReLU(inplace=True),
                nn.Dropout(dropout)
            ])
            prev = h
        self.network = nn.Sequential(*layers)
        self.output_dim = hidden_dims[-1]

    def forward(self, x):
        return self.network(x)


class DrugResponsePredictor(nn.Module):
    def __init__(self, input_dim, hidden_dims, output_dim=1, dropout=0.2):
        super(DrugResponsePredictor, self).__init__()
        layers = []
        prev = input_dim
        for h in hidden_dims:
            layers.extend([
                nn.Linear(prev, h),
                nn.BatchNorm1d(h),
                nn.ReLU(inplace=True),
                nn.Dropout(dropout)
            ])
            prev = h
        layers.append(nn.Linear(prev, output_dim))
        self.network = nn.Sequential(*layers)

    def forward(self, x):
        return self.network(x)


class DomainDiscriminator(nn.Module):
    def __init__(self, input_dim, hidden_dims, output_dim=2, dropout=0.2):
        super(DomainDiscriminator, self).__init__()
        layers = []
        prev = input_dim
        for h in hidden_dims:
            layers.extend([
                nn.Linear(prev, h),
                nn.BatchNorm1d(h),
                nn.ReLU(inplace=True),
                nn.Dropout(dropout)
            ])
            prev = h
        layers.append(nn.Linear(prev, output_dim))
        self.network = nn.Sequential(*layers)

    def forward(self, x):
        return self.network(x)


class DomainAdaptationNetwork(nn.Module):
    def __init__(self, config):
        super(DomainAdaptationNetwork, self).__init__()
        fe = config['feature_extractor']
        dp = config['drug_predictor']
        dd = config['domain_discriminator']

        self.feature_extractor = FeatureExtractor(input_dim=fe['input_dim'], hidden_dims=fe['hidden_dims'], dropout=fe.get('dropout', 0.2))
        self.drug_predictor = DrugResponsePredictor(input_dim=dp['input_dim'], hidden_dims=dp['hidden_dims'], output_dim=dp.get('output_dim', 1), dropout=dp.get('dropout', 0.2))
        self.gradient_reversal = GradientReversalLayer()
        self.domain_discriminator = DomainDiscriminator(input_dim=dd['input_dim'], hidden_dims=dd['hidden_dims'], output_dim=dd.get('output_dim', 2), dropout=dd.get('dropout', 0.2))

    def forward(self, x, lambda_=1.0):
        features = self.feature_extractor(x)
        drug_response = self.drug_predictor(features)
        self.gradient_reversal.set_lambda(lambda_)
        reversed_features = self.gradient_reversal(features)
        domain_pred = self.domain_discriminator(reversed_features)
        return drug_response, domain_pred

    def extract_features(self, x):
        return self.feature_extractor(x)

    def predict_drug_response(self, x):
        return self.drug_predictor(self.feature_extractor(x))
