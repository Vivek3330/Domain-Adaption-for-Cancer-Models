import os
import torch
import torch.nn as nn
import numpy as np
from itertools import cycle
import logging

logger = logging.getLogger(__name__)


def dann_lambda(epoch, total_epochs):
    p = epoch / float(max(1, total_epochs))
    return 2.0 / (1.0 + np.exp(-10 * p)) - 1.0


class DomainAdaptationTrainer:
    def __init__(self, config, model, source_loader, val_loader, target_loader=None, device='cpu'):
        self.config = config
        self.model = model.to(device)
        self.source_loader = source_loader
        self.val_loader = val_loader
        self.target_loader = target_loader
        self.device = device

        # Losses & optimizer
        self.criterion_reg = nn.MSELoss()
        self.criterion_domain = nn.CrossEntropyLoss()
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=self.config['training']['learning_rate'], weight_decay=self.config['training'].get('weight_decay', 0.0))

        self.epochs = self.config['training'].get('epochs', 50)
        self.domain_weight = self.config['training'].get('domain_loss_weight', 1.0)
        self.batch_size = self.config['training'].get('batch_size', 64)

        self.checkpoint_dir = os.path.join(self.config['logging']['log_dir'], 'checkpoints')
        os.makedirs(self.checkpoint_dir, exist_ok=True)

        self.best_val_loss = float('inf')
        self.best_ckpt = None

    def _validate(self):
        self.model.eval()
        total = 0.0
        count = 0
        preds = []
        trues = []
        with torch.no_grad():
            for batch in self.val_loader:
                x = batch['features'].to(self.device)
                y = batch['response'].to(self.device)
                pred, _ = self.model(x, lambda_=0.0)
                loss = self.criterion_reg(pred.squeeze(), y)
                total += float(loss.item()) * x.size(0)
                count += x.size(0)
                preds.extend(pred.squeeze().cpu().numpy().tolist())
                trues.extend(y.cpu().numpy().tolist())
        avg = total / max(1, count)
        return avg, np.array(trues), np.array(preds)

    def train(self):
        use_target = self.target_loader is not None
        if use_target:
            target_iter = cycle(self.target_loader)

        for epoch in range(1, self.epochs + 1):
            self.model.train()
            lambda_adv = dann_lambda(epoch, self.epochs) * self.domain_weight
            logger.info(f"Epoch {epoch}/{self.epochs} - adv lambda: {lambda_adv:.4f}")

            running_loss = 0.0
            running_reg = 0.0
            running_domain = 0.0
            batches = 0

            for batch_src in self.source_loader:
                x_src = batch_src['features'].to(self.device)
                y_src = batch_src['response'].to(self.device)

                if use_target:
                    batch_tgt = next(target_iter)
                    x_tgt = batch_tgt['features'].to(self.device)
                else:
                    x_tgt = x_src.clone()

                pred_src, domain_src = self.model(x_src, lambda_=lambda_adv)
                _, domain_tgt = self.model(x_tgt, lambda_=lambda_adv)

                reg_loss = self.criterion_reg(pred_src.squeeze(), y_src)

                domain_preds = torch.cat([domain_src, domain_tgt], dim=0)
                domain_labels = torch.cat([
                    torch.zeros(domain_src.size(0), dtype=torch.long),
                    torch.ones(domain_tgt.size(0), dtype=torch.long)
                ], dim=0).to(self.device)

                domain_loss = self.criterion_domain(domain_preds, domain_labels)

                loss = reg_loss + self.domain_weight * domain_loss

                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()

                running_loss += float(loss.item())
                running_reg += float(reg_loss.item())
                running_domain += float(domain_loss.item())
                batches += 1

            avg_loss = running_loss / max(1, batches)
            avg_reg = running_reg / max(1, batches)
            avg_domain = running_domain / max(1, batches)

            val_loss, y_true, y_pred = self._validate()
            if val_loss < self.best_val_loss:
                self.best_val_loss = val_loss
                ckpt = {
                    'epoch': epoch,
                    'model_state_dict': self.model.state_dict(),
                    'optimizer_state_dict': self.optimizer.state_dict(),
                    'val_loss': val_loss
                }
                path = os.path.join(self.checkpoint_dir, f'best_epoch_{epoch}.pt')
                torch.save(ckpt, path)
                self.best_ckpt = path
                logger.info(f"Saved best checkpoint: {path}")

            logger.info(f"Epoch {epoch}: train_loss={avg_loss:.6f}, reg={avg_reg:.6f}, domain={avg_domain:.6f}, val_loss={val_loss:.6f}")

        return self.best_ckpt
