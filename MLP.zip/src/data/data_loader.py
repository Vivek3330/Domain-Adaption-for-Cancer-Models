import os
import pandas as pd
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader as TorchDataLoader
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import logging

logger = logging.getLogger(__name__)


class DrugResponseDataset(Dataset):
    def __init__(self, features, responses, domains, drug_ids=None):
        self.features = torch.FloatTensor(features)
        self.responses = torch.FloatTensor(responses)
        self.domains = torch.LongTensor(domains)
        self.drug_ids = torch.LongTensor(drug_ids) if drug_ids is not None else None

    def __len__(self):
        return len(self.features)

    def __getitem__(self, idx):
        item = {
            'features': self.features[idx],
            'response': self.responses[idx],
            'domain': self.domains[idx]
        }
        if self.drug_ids is not None:
            item['drug_id'] = self.drug_ids[idx]
        return item


class DataLoader:
    def __init__(self, config):
        self.config = config
        self.scaler = StandardScaler()

    def _read_csv_safe(self, path, name):
        if not os.path.exists(path):
            raise FileNotFoundError(f"{name} data not found at {path}")
        df = pd.read_csv(path)
        logger.info(f"Loaded {name} data: {df.shape}")
        return df

    def load_gdsc_data(self, file_path):
        df = self._read_csv_safe(file_path, "GDSC")
        if 'drug_response' not in df.columns:
            raise ValueError("GDSC data must contain 'drug_response' column")
        exclude_cols = ['drug_response', 'sample_id']
        gene_columns = [c for c in df.columns if c not in exclude_cols]
        df[gene_columns] = df[gene_columns].apply(lambda x: pd.to_numeric(x.astype(str).str.strip(), errors='coerce'))
        df['drug_response'] = pd.to_numeric(df['drug_response'].astype(str).str.strip(), errors='coerce')
        features = df[gene_columns].values.astype(np.float32)
        responses = df['drug_response'].values.astype(np.float32)
        if np.isnan(features).any():
            from sklearn.impute import SimpleImputer
            features = SimpleImputer(strategy='median').fit_transform(features)
        if np.isnan(responses).any():
            responses = np.nan_to_num(responses, nan=np.nanmedian(responses))
        domains = np.zeros(len(df), dtype=np.int64)
        return features, responses, domains

    def load_tcga_data(self, file_path):
        df = self._read_csv_safe(file_path, "TCGA")
        if 'drug_response' not in df.columns:
            raise ValueError("TCGA data must contain 'drug_response' column")
        exclude_cols = ['drug_response', 'sample_id']
        gene_columns = [c for c in df.columns if c not in exclude_cols]
        df[gene_columns] = df[gene_columns].apply(lambda x: pd.to_numeric(x.astype(str).str.strip(), errors='coerce'))
        df['drug_response'] = pd.to_numeric(df['drug_response'].astype(str).str.strip(), errors='coerce')
        features = df[gene_columns].values.astype(np.float32)
        responses = df['drug_response'].values.astype(np.float32)
        if np.isnan(features).any():
            from sklearn.impute import SimpleImputer
            features = SimpleImputer(strategy='median').fit_transform(features)
        if np.isnan(responses).any():
            responses = np.nan_to_num(responses, nan=np.nanmedian(responses))
        domains = np.ones(len(df), dtype=np.int64)
        return features, responses, domains

    def preprocess(self, features, log_transform=False):
        if log_transform:
            features = np.log1p(np.maximum(features, 0))
        return self.scaler.transform(features) if features is not None else None

    def create_data_loaders(self):
        gdsc_features, gdsc_responses, gdsc_domains = self.load_gdsc_data(self.config['data']['gdsc_path'])
        logger.info(f"GDSC samples: {gdsc_features.shape[0]}, features: {gdsc_features.shape[1]}")

        tcga_features = tcga_responses = tcga_domains = None
        tcga_path = self.config['data'].get('tcga_path', None)
        if tcga_path:
            try:
                tcga_features, tcga_responses, tcga_domains = self.load_tcga_data(tcga_path)
                logger.info(f"TCGA samples: {tcga_features.shape[0]}, features: {tcga_features.shape[1]}")
            except Exception as e:
                logger.warning(f"TCGA loading skipped: {e}")
                tcga_features = tcga_responses = tcga_domains = None

        log_transform = self.config['data'].get('log_transform', False)
        if log_transform:
            gdsc_features = np.log1p(np.maximum(gdsc_features, 0))
            if tcga_features is not None:
                tcga_features = np.log1p(np.maximum(tcga_features, 0))

        if self.config['data'].get('normalize', True):
            logger.info("Fitting StandardScaler on GDSC features only.")
            self.scaler.fit(gdsc_features)
            gdsc_features = self.scaler.transform(gdsc_features)
            if tcga_features is not None:
                tcga_features = self.scaler.transform(tcga_features)

        train_features, val_features, train_responses, val_responses, train_domains, val_domains = train_test_split(
            gdsc_features, gdsc_responses, gdsc_domains,
            test_size=self.config['data'].get('test_split', 0.2),
            random_state=self.config.get('seed', 42)
        )

        batch_size = self.config['training'].get('batch_size', 64)
        train_dataset = DrugResponseDataset(train_features, train_responses, train_domains)
        val_dataset = DrugResponseDataset(val_features, val_responses, val_domains)

        data_loaders = {
            'train': TorchDataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=self.config['data'].get('num_workers', 4), drop_last=True),
            'val': TorchDataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=self.config['data'].get('num_workers', 4), drop_last=False)
        }

        if tcga_features is not None and tcga_responses is not None:
            tcga_dataset = DrugResponseDataset(tcga_features, tcga_responses, tcga_domains)
            data_loaders['tcga'] = TorchDataLoader(tcga_dataset, batch_size=batch_size, shuffle=True, num_workers=self.config['data'].get('num_workers', 4), drop_last=True)
            logger.info("Added TCGA dataloader for training/eval.")
        else:
            logger.info("No TCGA loader added.")

        return data_loaders
