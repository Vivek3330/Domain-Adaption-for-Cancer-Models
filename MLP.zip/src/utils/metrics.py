import numpy as np
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score, accuracy_score, precision_recall_fscore_support, confusion_matrix
from scipy.stats import pearsonr, spearmanr
import torch
import logging

logger = logging.getLogger(__name__)


def calculate_metrics(y_true, y_pred, logger=None):

    def to_numpy(x):
        if isinstance(x, list):
            x = np.concatenate([to_numpy(i) for i in x])
        elif torch.is_tensor(x):
            x = x.cpu().numpy()
        elif isinstance(x, np.ndarray):
            x = x.flatten()
        else:
            x = np.array(x).flatten()
        return x

    y_true = to_numpy(y_true)
    y_pred = to_numpy(y_pred)

    mse = mean_squared_error(y_true, y_pred)
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_true, y_pred)

    try:
        pearson_corr, pearson_p = pearsonr(y_true, y_pred)
        spearman_corr, spearman_p = spearmanr(y_true, y_pred)
    except Exception as e:
        if logger:
            logger.warning(f"Error calculating correlations: {e}")
        pearson_corr = pearson_p = spearman_corr = spearman_p = np.nan

    return {
        'mse': mse,
        'mae': mae,
        'rmse': rmse,
        'r2': r2,
        'pearson': pearson_corr,
        'pearson_p': pearson_p,
        'spearman': spearman_corr,
        'spearman_p': spearman_p
    }

import numpy as np
import torch
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, confusion_matrix

def calculate_domain_metrics(domain_true, domain_pred):

    def to_numpy(x):
        if isinstance(x, list):
            x = np.concatenate([to_numpy(i) for i in x])
        elif torch.is_tensor(x):
            x = x.cpu().numpy()
        elif isinstance(x, np.ndarray):
            x = x.flatten()
        else:
            x = np.array(x).flatten()
        return x

    domain_true = to_numpy(domain_true)
    domain_pred = to_numpy(domain_pred)

    if domain_pred.ndim > 1 and domain_pred.shape[1] > 1:
        domain_pred = np.argmax(domain_pred, axis=1)

    all_labels = np.unique(np.concatenate([domain_true, domain_pred]))

    accuracy = accuracy_score(domain_true, domain_pred)
    precision, recall, f1, _ = precision_recall_fscore_support(
        domain_true, domain_pred, average='weighted', zero_division=0
    )
    cm = confusion_matrix(domain_true, domain_pred, labels=[0,1])

    return {
        'domain_accuracy': accuracy,
        'domain_precision': precision,
        'domain_recall': recall,
        'domain_f1': f1,
        'confusion_matrix': cm
    }


def evaluate_domain(model, data_loader, device, domain_name="unknown"):
    model.eval()
    all_predictions, all_responses = [], []
    all_domain_preds, all_domains = [], []

    with torch.no_grad():
        for batch in data_loader:
            features = batch['features'].to(device)
            responses = batch['response'].to(device)
            domains = batch['domain'].to(device)

            drug_pred, domain_pred = model(features, lambda_=0)

            all_predictions.append(drug_pred.squeeze())
            all_responses.append(responses)
            all_domain_preds.append(torch.argmax(domain_pred, dim=1))
            all_domains.append(domains)

    regression_metrics = calculate_metrics(all_responses, all_predictions, logger)
    domain_metrics = calculate_domain_metrics(all_domains, all_domain_preds)

    combined_metrics = {f"{domain_name}_{k}": v for k, v in {**regression_metrics, **domain_metrics}.items()}
    return combined_metrics


class DomainAdaptationEvaluator:
    def __init__(self, model, config, device):
        self.model = model
        self.config = config
        self.device = device

    def evaluate_comprehensive(self, data_loaders):
        results = {}
        for domain_name, loader in data_loaders.items():
            results.update(evaluate_domain(self.model, loader, self.device, domain_name))

        if 'train' in data_loaders and 'tcga' in data_loaders:
            results['cross_domain'] = self.evaluate_cross_domain(data_loaders['train'], data_loaders['tcga'])
            results['domain_invariance'] = self.calculate_domain_invariance(data_loaders['train'], data_loaders['tcga'])
        return results

    def evaluate_cross_domain(self, source_loader, target_loader):
        from copy import deepcopy
        source_metrics = evaluate_domain(self.model, source_loader, self.device, "source")
        target_metrics = evaluate_domain(self.model, target_loader, self.device, "target")

        mse_gap = target_metrics['target_mse'] - source_metrics['source_mse']
        pearson_gap = source_metrics['source_pearson'] - target_metrics['target_pearson']

        return {
            'source_metrics': source_metrics,
            'target_metrics': target_metrics,
            'mse_gap': mse_gap,
            'pearson_gap': pearson_gap,
            'domain_transfer_success': pearson_gap < 0.3
        }

    def calculate_domain_invariance(self, source_loader, target_loader):
        self.model.eval()
        source_features, target_features = [], []

        with torch.no_grad():
            for batch in source_loader:
                features = batch['features'].to(self.device)
                source_features.append(self.model.extract_features(features).cpu().numpy())
            for batch in target_loader:
                features = batch['features'].to(self.device)
                target_features.append(self.model.extract_features(features).cpu().numpy())

        source_features = np.concatenate(source_features, axis=0)
        target_features = np.concatenate(target_features, axis=0)

        from scipy.spatial.distance import euclidean
        from scipy.stats import wasserstein_distance

        mean_distance = euclidean(np.mean(source_features, axis=0), np.mean(target_features, axis=0))
        wasserstein_distances = [wasserstein_distance(source_features[:, i], target_features[:, i]) for i in range(source_features.shape[1])]
        avg_wasserstein = np.mean(wasserstein_distances)

        return {
            'mean_feature_distance': mean_distance,
            'avg_wasserstein_distance': avg_wasserstein,
            'max_wasserstein_distance': np.max(wasserstein_distances),
            'feature_alignment_score': 1.0 / (1.0 + avg_wasserstein)
        }
