import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import os

gdsc_path = "data/processed/gdsc.csv"
tcga_path = "data/processed/tcga.csv"

print("🔹 Loading datasets...")
gdsc = pd.read_csv(gdsc_path)
tcga = pd.read_csv(tcga_path)

target_col = gdsc.columns[-1]
print(f" Target column detected: {target_col}")

X_gdsc = gdsc.drop(columns=[target_col])
y_gdsc = gdsc[target_col]

X_tcga = tcga.drop(columns=[target_col], errors="ignore")
y_tcga = tcga[target_col] if target_col in tcga.columns else None


common_cols = X_gdsc.columns.intersection(X_tcga.columns)
X_gdsc = X_gdsc[common_cols]
X_tcga = X_tcga[common_cols]
print(f"Found {len(common_cols)} common genes/features.")


combined = pd.concat([X_gdsc, X_tcga], axis=0)


combined_log = np.log1p(combined)


std_scaler = StandardScaler()
combined_std = std_scaler.fit_transform(combined_log)


minmax_scaler = MinMaxScaler()
combined_scaled = minmax_scaler.fit_transform(combined_std)

X_gdsc_scaled = combined_scaled[:len(X_gdsc)]
X_tcga_scaled = combined_scaled[len(X_gdsc):]


gdsc_scaled = pd.DataFrame(X_gdsc_scaled, columns=common_cols)
gdsc_scaled.insert(gdsc.columns.get_loc(target_col), target_col, y_gdsc.values)

tcga_scaled = pd.DataFrame(X_tcga_scaled, columns=common_cols)
if y_tcga is not None:
    tcga_scaled.insert(tcga.columns.get_loc(target_col), target_col, y_tcga.values)


print("🔧 Replacing zeros with column medians...")

def fill_zeros_with_median(df, target_col):
    features = df.drop(columns=[target_col])
    for col in features.columns:
        median_val = features[col].median()
        features[col] = features[col].replace(0, median_val)
    df.update(features)
    return df

gdsc_scaled = fill_zeros_with_median(gdsc_scaled, target_col)
tcga_scaled = fill_zeros_with_median(tcga_scaled, target_col)


os.makedirs("data/processed2", exist_ok=True)
gdsc_scaled.to_csv("data/processed2/gdsc_log_normalised.csv", index=False)
tcga_scaled.to_csv("data/processed2/tcga_log_normalised.csv", index=False)

print("Log + Standard + MinMax + Median fill complete!")
print("data/processed2/gdsc_log_normalised.csv")
print("data/processed2/tcga_log_normalised.csv")
