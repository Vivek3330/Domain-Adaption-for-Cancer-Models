import os
import argparse
import time
import math
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from torch.optim import Adam
from torch.optim.lr_scheduler import CyclicLR

# drop path implementation
class DropPath(nn.Module):
    def __init__(self, drop_prob: float = 0.0):
        super().__init__()
        self.drop_prob = drop_prob
    def forward(self, x):
        if self.drop_prob == 0.0 or not self.training:
            return x
        keep_prob = 1 - self.drop_prob
        shape = (x.shape[0],) + (1,) * (x.dim() - 1)
        random_tensor = keep_prob + torch.rand(shape, dtype=x.dtype, device=x.device)
        binary_tensor = torch.floor(random_tensor)
        return x.div(keep_prob) * binary_tensor

# our model

class TransformerBlockWithDropPath(nn.Module):
    def __init__(self, d_model, nhead, dim_feedforward=2048, dropout=0.1, drop_path=0.2):
        super().__init__()
        self.layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=dim_feedforward,
            dropout=dropout,
            activation='gelu'
        )
        self.drop_path = DropPath(drop_path)

    def forward(self, src):
        out = self.layer(src)
        return self.drop_path(out)

class HybridTransformerMLP(nn.Module):
    def __init__(self, input_dim, seq_len=16, d_model=128,
                 nhead=4, num_layers=4, mlp_hidden=256,
                 drop_path_rate=0.1, dropout=0.1):
        super().__init__()

        self.input_proj = nn.Linear(input_dim, d_model)
        self.pos_embed = nn.Parameter(torch.zeros(1, seq_len, d_model))
        self.seq_len = seq_len

        self.blocks = nn.ModuleList()
        for i in range(num_layers):
            dp = drop_path_rate * i / max(1, num_layers - 1)
            self.blocks.append(
                TransformerBlockWithDropPath(
                    d_model, nhead, d_model * 4, dropout, dp
                )
            )

        self.norm = nn.LayerNorm(d_model)

        self.mlp = nn.Sequential(
            nn.Linear(input_dim, mlp_hidden), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(mlp_hidden, mlp_hidden), nn.GELU()
        )

        fused = d_model + mlp_hidden
        self.regressor = nn.Sequential(
            nn.LayerNorm(fused),
            nn.Linear(fused, fused // 2), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(fused // 2, 1)
        )

        nn.init.trunc_normal_(self.pos_embed, std=0.02)

    def forward(self, x):
        proj = self.input_proj(x)                       
        seq = proj.unsqueeze(1).repeat(1, self.seq_len, 1) + self.pos_embed
        seq = seq.transpose(0, 1)                      
        for blk in self.blocks:
            seq = blk(seq)
        seq = seq.transpose(0, 1)                     
        trans_feat = self.norm(seq.mean(dim=1))        
        mlp_feat = self.mlp(x)                         
        fused = torch.cat([trans_feat, mlp_feat], dim=-1)
        out = self.regressor(fused)
        return out.squeeze(-1)

# extracting dataset

class GeneExpressionDataset(Dataset):
    def __init__(self, df, features, target_col):
        self.X = df[features].values.astype(np.float32)
        self.y = df[target_col].values.astype(np.float32)
    def __len__(self): return len(self.X)
    def __getitem__(self, i): return self.X[i], self.y[i], 0

# mixup augementation implementation
def mixup_data(x, y, alpha=0.4):
    if alpha <= 0: return x, y, 1.0, None
    lam = float(torch.distributions.Beta(alpha, alpha).sample())
    idx = torch.randperm(x.size(0)).to(x.device)
    x2 = lam * x + (1 - lam) * x[idx]
    return x2, (y, y[idx]), lam, idx

# SAM optimizer code
class SAM:
    def __init__(self, params, base_optim, rho=0.05, adaptive=False, **kw):
        self.params = list(params)
        self.opt = base_optim(self.params, **kw)
        self.rho, self.adaptive = rho, adaptive

    @torch.no_grad()
    def first_step(self, zero_grad=True):
        scale = self.rho / (self._norm() + 1e-12)
        for p in self.params:
            if p.grad is None: continue
            e = (p.abs() if self.adaptive else 1.0) * p.grad * scale
            p.add_(e); p._e = e
        if zero_grad: self.opt.zero_grad()

    @torch.no_grad()
    def second_step(self, zero_grad=True):
        for p in self.params:
            if hasattr(p, '_e'):
                p.sub_(p._e); del p._e
        self.opt.step()
        if zero_grad: self.opt.zero_grad()

    def _norm(self):
        norms = [((p.abs() if self.adaptive else 1.0) * p.grad).norm() for p in self.params if p.grad is not None]
        return torch.norm(torch.stack(norms)) if len(norms)>0 else torch.tensor(0.0, device=self.params[0].device)

# performance metrics

def compute_metrics(y, yhat):
    mse = mean_squared_error(y, yhat)
    return {
        'mse': mse,
        'rmse': math.sqrt(mse),
        'mae': mean_absolute_error(y, yhat),
        'r2': r2_score(y, yhat)
    }

# model training 

def train_epoch(model, loader, crit, sam, dev, mixup):
    model.train()
    total = 0
    loss_sum = 0.0
    for x, y, _ in loader:
        x = x.to(dev).float()
        y = y.to(dev).float()
        if mixup > 0:
            xm, (a, b), lam, _ = mixup_data(x, y, mixup)
            preds = model(xm)
            loss = lam * crit(preds, a) + (1 - lam) * crit(preds, b)
        else:
            preds = model(x)
            loss = crit(preds, y)

        loss.backward()
        sam.first_step(zero_grad=True)

        # second forward/backward
        if mixup > 0:
            preds2 = model(xm)
            loss2 = lam * crit(preds2, a) + (1 - lam) * crit(preds2, b)
        else:
            preds2 = model(x)
            loss2 = crit(preds2, y)

        loss2.backward()
        sam.second_step(zero_grad=True)

        loss_sum += loss.item() * x.size(0)
        total += x.size(0)

    return loss_sum / total if total > 0 else 0.0

# evaluating model(validtaion)

def eval_epoch(model, loader, crit, dev):
    model.eval()
    Ys = []
    Ps = []
    total_loss = 0.0
    n = 0
    with torch.no_grad():
        for x, y, _ in loader:
            x = x.to(dev).float()
            y = y.to(dev).float()
            preds = model(x)
            loss = crit(preds, y)
            total_loss += loss.item() * x.size(0)
            n += x.size(0)
            Ys.append(y.cpu().numpy())
            Ps.append(preds.cpu().numpy())
    if n == 0:
        return {'loss': 0.0, 'mse': 0.0, 'rmse': 0.0, 'mae': 0.0, 'r2': 0.0}
    Y = np.concatenate(Ys)
    P = np.concatenate(Ps)
    m = compute_metrics(Y, P)
    m['loss'] = total_loss / n
    return m

# prepocessing code

def load_data(data_dir):
    gdsc_path = os.path.join(data_dir, 'gdsc_log_normalised.csv')
    tcga_path = os.path.join(data_dir, 'tcga_log_normalised.csv')
    if not os.path.exists(gdsc_path) or not os.path.exists(tcga_path):
        raise FileNotFoundError(f"Expected files at: {gdsc_path} and {tcga_path}")
    g = pd.read_csv(gdsc_path)
    t = pd.read_csv(tcga_path)
    features = [c for c in g.columns if c.startswith('gene_')]
    target = 'drug_response'
    if target not in g.columns or target not in t.columns:
        raise KeyError(f"Target column '{target}' not found in CSVs")
    return g, t, features, target

def preprocess(g, t, features):
    g = g.copy(); t = t.copy()
    # fill missing
    g[features] = g[features].fillna(g[features].median())
    t[features] = t[features].fillna(t[features].median())
    # fit scaler on source only
    scaler = StandardScaler()
    scaler.fit(g[features].values)
    g[features] = scaler.transform(g[features].values)
    t[features] = scaler.transform(t[features].values)
    return g, t, scaler

# starting the model

def run_option1(args, device):
    print('>> OPTION1: Classical Domain Transfer (GDSC → TCGA)')
    g, t, features, target = load_data(args.data_dir)
    g, t, scaler = preprocess(g, t, features)

    train_ds = GeneExpressionDataset(g, features, target)
    val_ds = GeneExpressionDataset(t, features, target)

    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, num_workers=0)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False, num_workers=0)

    model = HybridTransformerMLP(
        input_dim=len(features),
        seq_len=args.seq_len,
        d_model=args.d_model,
        nhead=args.nhead,
        num_layers=args.num_layers,
        mlp_hidden=args.mlp_hidden,
        drop_path_rate=args.drop_path_rate,
        dropout=args.dropout
    ).to(device)

    criterion = nn.MSELoss()
    sam = SAM(model.parameters(), Adam, rho=args.rho, adaptive=args.adaptive, lr=args.lr)
    scheduler = CyclicLR(sam.opt, base_lr=args.lr / 10.0, max_lr=args.lr, step_size_up=args.step_size_up, mode='triangular2')

    best_rmse = float('inf')
    patience_counter = 0

    print("Starting training on device:", device)
    for epoch in range(1, args.epochs + 1):
        t0 = time.time()
        train_loss = train_epoch(model, train_loader, criterion, sam, device, args.mixup_alpha)
        val_metrics = eval_epoch(model, val_loader, criterion, device)
        scheduler.step()
        elapsed = time.time() - t0

        print(f"Epoch {epoch:03d} | TrainLoss: {train_loss:.6f} | Val RMSE: {val_metrics['rmse']:.6f} | MAE: {val_metrics['mae']:.6f} | R2: {val_metrics['r2']:.4f} | Time: {elapsed:.1f}s")

        # save best model
        if val_metrics['rmse'] < best_rmse:
            best_rmse = val_metrics['rmse']
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'scaler': scaler
            }, args.save_path)
            print(f"Saved best model (RMSE={best_rmse:.6f}) to {args.save_path}")
            patience_counter = 0
        else:
            patience_counter += 1

        if patience_counter >= args.patience:
            print("Early stopping triggered.")
            break

    print("Training finished. Best Val RMSE:", best_rmse)

# adding parameters values

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-dir', type=str, required=True, help='Path to folder with gdsc_log_normalised.csv and tcga_log_normalised.csv')
    parser.add_argument('--epochs', type=int, default=100)
    parser.add_argument('--batch-size', type=int, default=64)
    parser.add_argument('--seq-len', type=int, default=16)
    parser.add_argument('--d-model', type=int, default=128)
    parser.add_argument('--nhead', type=int, default=4)
    parser.add_argument('--num-layers', type=int, default=4)
    parser.add_argument('--mlp-hidden', type=int, default=256)
    parser.add_argument('--drop-path-rate', type=float, default=0.1)
    parser.add_argument('--dropout', type=float, default=0.1)
    parser.add_argument('--lr', type=float, default=1e-3)
    parser.add_argument('--rho', type=float, default=0.05)
    parser.add_argument('--adaptive', action='store_true')
    parser.add_argument('--mixup-alpha', type=float, default=0.4)
    parser.add_argument('--patience', type=int, default=10)
    parser.add_argument('--save-path', type=str, default='best_model_option1.pth')
    parser.add_argument('--step-size-up', type=int, default=200)
    return parser.parse_args()

if __name__ == '__main__':
    args = parse_args()
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    run_option1(args, device)
